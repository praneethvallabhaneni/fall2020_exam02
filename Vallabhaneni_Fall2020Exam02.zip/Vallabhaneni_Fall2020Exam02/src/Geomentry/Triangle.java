/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Geomentry;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class Triangle extends GeometricObject {
    private double tSide1;
    private double tSide2;
    private double tSide3;
    
    public Triangle() {
        super("Yellow", false);
        tSide1 = 1;
        tSide2 = 1;
        tSide3 = 1;
    }

    public Triangle(double s1, double s2, double s3, String color, boolean filled) 
                                        throws TriangleException {
                                            
        super(color, filled);
        if (s1 + s2 < s3 || s2 + s3 < s1 || s1 + s3 < s2) {
            throw new TriangleException("Any two sides added together" + 
                " must be greater than the remaining side.  NO side may equal 0!");
        }
        tSide1 = s1;
        tSide2 = s2;
        tSide3 = s3;
    }
    
    public double getSideOne() {
        return tSide1;
    }
    
    public double getSideTwo() {
        return tSide3;
    }
    
    public double getSideThree() {
        return tSide3;
    }
    
    public double getArea() {
        double perimeter = tSide1 + tSide2 + tSide3;
        return Math.sqrt(perimeter * (
                                            (perimeter - tSide1) * 
                                            (perimeter - tSide2) * 
                                            (perimeter - tSide3)));
    }
    
    public double getPerimeter() {
        return (tSide1 + tSide2 + tSide3);
    }

    @Override
    public String toString() {
        return "Triangle: side1 = " + tSide1 + " side2 = " + tSide2 +
               " side3 = " + tSide3;
    }
    
}

