/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Geomentry;

import java.util.Scanner;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class GeomentryDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner in = new Scanner(System.in);
        System.out.print("Please enter 3 sides of a triangle, color and " +
                        "whether it is filled or not (true false): ");
        double s1 = in.nextDouble();
        double s2 = in.nextDouble();
        double s3 = in.nextDouble();
        String color = in.next();
        boolean filled = in.nextBoolean();
        
        Triangle t1 = null;
        
        try {
            t1 = new Triangle(s1, s2, s3, color, filled);
        }
        catch (TriangleException ex) {
            System.out.println(ex.toString());
        }
        
        System.out.println(t1.toString());
        System.out.printf("Triangle color: %s, Triangle filled: %s%n" + 
                        "Area: %.2f%n" + 
                        "Perimeter: %.2f%n%n",
                    t1.getColor(), 
                    t1.isFilled(),
                    t1.getArea(),
                    t1.getPerimeter());
            
        
    }
}
    
