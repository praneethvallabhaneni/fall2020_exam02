/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OneDimensionalArray;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class RemoveDuplicateList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
		Scanner input = new Scanner(System.in);

		
		ArrayList<Integer> list = new ArrayList<Integer>();

	
		System.out.print("Enter the list of 10 integers: ");
		for (int i = 0; i < 10; i++) {
			list.add(input.nextInt());
		}

	
		removeDuplicate(list);


	}

	
	public static void removeDuplicate(ArrayList<Integer> list) {

		Set<Integer> hashSet = new LinkedHashSet(list);
        ArrayList<Integer> removedDuplicates = new ArrayList(hashSet);

        System.out.println("The distinct integers are:"+removedDuplicates);
	}
}
    

