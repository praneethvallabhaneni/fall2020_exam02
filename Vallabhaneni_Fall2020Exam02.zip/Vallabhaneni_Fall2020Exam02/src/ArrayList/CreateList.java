/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArrayList;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class CreateList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        		// Create an array list of objects
		ArrayList<Object> ob = new ArrayList<Object>();
		ob.add(new Loan());		
		ob.add(new Date());		
		ob.add(new String("It is a string class"));	
		ob.add(new Circle());	

		// Display all the elements in the list by 
		// invoking the object’s toString() method
		for (int i = 0; i < ob.size(); i++) {
			System.out.println((ob.get(i)).toString());
		}
	}
}
    
