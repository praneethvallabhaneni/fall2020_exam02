/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArrayList;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class Loan {
    
	private int amount;
	private double intrestRate;
	public Loan() {
		this(10000,2);
	}
	public Loan( int amount, double intrestRate) {
		super();
	
		this.amount = amount;
		this.intrestRate = intrestRate;
	}
	@Override
	public String toString() {
		return "Loan [amount=" + amount + ", intrestRate=" + intrestRate + "]";
	}

	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public double getIntrestRate() {
		return intrestRate;
	}
	public void setIntrestRate(double intrestRate) {
		this.intrestRate = intrestRate;
	}
	

}

    

