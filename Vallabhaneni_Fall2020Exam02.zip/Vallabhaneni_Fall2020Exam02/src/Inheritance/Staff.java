/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class Staff extends Employee {
String title;



public Staff(String name, String address, String phone, String mail, String office, double salary, String date_hired,
		String title) {
	super(name, address, phone, mail, office, salary, date_hired);
	this.title = title;
	
}



@Override
public String toString() {
	return "Staff [title=" + title
                + ", office=" + office + ", salary=" + salary + ", date_hired=" + date_hired + ", name=" +
                name + ", address=" + address + ", phone=" + phone + ", mail=" + mail + "]";
}

}

