/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class DetailsDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Person person = new Person("John Doe", "123 Somewhere", "415-555-1212", "johndoe@somewhere.com");
       Person student = new Student("Mary Jane", "555 School Street", "650-555-1212", "mj@abc.com","Pass" ,"junior");
       Person employee = new Employee("Ram","Dale Dr","234-1234-999","xyz@gmail.com","Cali",1234.30,"10/20/30");
       Person faculty = new Faculty("Ram","Dale Dr", "234-1234-569","XYZ@GMAIL.COM","Cali",1234.56,"10-22-2020",4.5,4);
       Person staff = new Staff("Ram","Dale Dr","123-4567-890","xyz@gmail.com","Cali",1234.56,"10/20/2020",
                        "Teaching Assistant");

		System.out.println(person.toString() + "\n");
		System.out.println(student.toString() + "\n");
		System.out.println(employee.toString() + "\n");
		System.out.println(faculty.toString() + "\n");
		System.out.println(staff.toString() + "\n");
		}
}

    