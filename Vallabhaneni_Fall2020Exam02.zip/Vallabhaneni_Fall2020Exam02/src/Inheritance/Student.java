/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class Student extends Person {
	String Grade;
	public final String CLASS_STATUS;

	public Student(String name, String address, String phone, String mail, String grade, String cLASS_STATUS) {
		super(name, address, phone, mail);
		Grade = grade;
		CLASS_STATUS = cLASS_STATUS;
	}

	@Override
	public String toString() {
		return "Student [Grade=" + Grade + ", CLASS_STATUS=" + CLASS_STATUS + ", name=" + name + ", address=" + address
				+ ", phone=" + phone + ", mail=" + mail +"]";
	}
	
	
	

}

	


