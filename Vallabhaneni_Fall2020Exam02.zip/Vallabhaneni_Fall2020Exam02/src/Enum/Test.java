/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Enum;

import static Enum.Day.FRIDAY;
import static Enum.Day.SUNDAY;
import static java.util.Calendar.MONDAY;
import static java.util.Calendar.SATURDAY;

/**
 *
 * @author Praneeth Vallabhaneni
 */

   enum Day 
{ 
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY, 
    THURSDAY, FRIDAY, SATURDAY; 
} 
class Test {
 
  private Day day;
    public Test(Day day) 
    { 
        this.day = day; 
    } 
  
    public void dayIsLike() 
    { 
       
        switch (day) 
        { 
        case MONDAY: 
            System.out.println("Mondays are bad."); 
            break; 
        case FRIDAY: 
            System.out.println("Fridays are better."); 
            break; 
        case SATURDAY: 
        case SUNDAY: 
            System.out.println("Weekends are best."); 
            break; 
        default: 
            System.out.println("Midweek days are so-so."); 
            break; 
        } 
    } 

    public static void main(String[] args) 
    { 
        String str = "MONDAY"; 
        Test t1 = new Test(Day.valueOf(str)); 
        t1.dayIsLike(); 
    } 
}
